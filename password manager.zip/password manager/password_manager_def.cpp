#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <sstream>
#include "password_manager.h"

using namespace std;

PasswordManager::PasswordManager()
{
	filename = "TextFile2.txt"; 
}

void PasswordManager::setMasterPassword(const string& password) //Sets master password as a constant string
{
	masterPassword = password; //Whatever was put into the setMasterPassword function gets saved as password which then in turn gets saved as masterPassword
}

bool PasswordManager::authenticate(const string& attempt)
{	
	return attempt == masterPassword; //Compares attempt to masterPassword and returns the value
}
	
bool PasswordManager::addCredential(const string& username, const string& password) //addCredential will be handling two values, both of which are constants and strings
{
	if (!strongPassword(password)) { //If the password passed into the function is NOT strong, the following code takes place
		cout << "Password is too weak. It must be at least 8 characters long and include a number and a symbol." << endl;
		return false;
	}

	if (findUser(username) == -1) { //If the specified username is NOT found, the following code takes place
		credentials.push_back({username, password}); //Adds the username and encrypted password
		cout << "Credentials added!" << endl;
		return true; 
	}

	else {
		cout << "Error, credentials already exist!" << endl; 
		return false;

	}
}

bool PasswordManager::deleteCredential(const string& username) //deleteCredential will be dealing with a constant string
{
	int index = findUser(username); //The value of index is set as the value of whatever findUser returns as
	if (index != -1) { //If it doesn't return as -1, the following code occurs. 
		credentials.erase(credentials.begin() + index); //The credentials at the index value are erased
		cout << "Credentials erased!" << endl;
		return true;
	}
	else {
		cout << "Credentials not found, try again." << endl;
		return false;
	}
}	

int PasswordManager::findUser(const string& username) { //findUser will be dealing with a constant string
	for (size_t i = 0; i < credentials.size(); i++) { //While i is less than the credentials size, this code will loop until it either breaks the condition or,
		if (credentials[i].first == username) { //Finds the value associated with the username
			return i;
		}
	}
	return -1;
}

string PasswordManager::getPassword(const string& username) //getPassword will be dealing with a constant string
{
	int index = findUser(username); //The value of index is set as whatever findUser returns as
	if (index != -1) { //If the username is found
		return credentials[index].second; //Returns the password associated with that username
	}
	else {
		cout << "User not found" << endl;
	}
}

void PasswordManager::saveToFile() {
	ofstream out(filename); //Outputs results into file specified in filename
	out << "Master " << encrypt(masterPassword) << endl; //Outputs the master password in an encrypted form
	for (const auto& entry : credentials) { 
		out << entry.first << " " << encrypt(entry.second) << endl; //Essentially, the constant's data type is automatically detected and the first entry is output normally (username)
	} //and the second entry is encrypted (password)
	out.close(); //Closes the file
}

void PasswordManager::fetchFromFile() {
	credentials.clear(); //Clears the current credentials vector to avoid duplicates when fetching from file
	ifstream in(filename); //Opens the file specified in filename
	if (!in.is_open()) { //If the file cannot be opened,
		return; //exit function
	}

	string line;
	while (getline(in, line)) { 
		if (line.empty()) continue; //Skips empty lines
		size_t pos = line.find(' '); //Find first space separating label and value
		if (pos == string::npos) continue; //If no space is found, skip line

		string label = line.substr(0, pos); //Extracts whatever is before the space as label
		string value = line.substr(pos + 1); //Extracts whatever is after the space as value

		if (label == "Master") {
			masterPassword = decrypt(value); //If the label is Master, sets masterPassword as the decrypted value
		}
		else {
			credentials.push_back({ label, decrypt(value) }); //Otherwise, adds the label (username) and decrypted value (password)
		}
	}

	in.close();
}



string PasswordManager::encrypt(string input) //encrypt will be handling a constant string
{
	string result = input;
	char key = 'K'; //Sets key as K
	for (char& c : result) { //For every character in the result variable
		c ^= key; //Encrypts it using XOR by the value of the key.
	}
	return result; //Return that as result
}

string PasswordManager::decrypt(const string input)
{
	return encrypt(input); //Return the result of input after being "encrypted" again
}

void PasswordManager::listCredentials()
{
	if (credentials.empty()) {  //If the credentials list in the text file is empty
		cout << "No credentials stored." << endl; 
		return;
	}
	else {
		cout << "Stored usernames:" << endl; 
		for (const auto& entry : credentials) { //Lists all credentials
			cout << "- " << entry.first << endl;
		}
	}
}

bool PasswordManager::updatePassword(const string& username, const string& newPassword) //updatePassword will be using constant strings
{
	int index = findUser(username); //The value of index is set as whatever username is
	if (index != -1) { //If the credential is found (not -1)
		credentials[index].second = newPassword; //Sets the second part of the vector as newPassword
		return true;
	}
	else {
		return false;
	}
}

string PasswordManager::getMasterPassword() const {
	return masterPassword;
}

bool PasswordManager::strongPassword(const string& password) { //strongPassword will be using a constant string
	if (password.length() < 8) return false; // If the password length is less than 8, return false

	bool digit = false;
	bool symbol = false;
	bool upper = false;
	bool lower = false;

	for (char c : password) {
		if (isdigit(c)) digit = true; //Checks if there's a digit, then sets digit to true
		else if (isalpha(c)) { // Checks if there's a letter
			if (islower(c)) lower = true; // Checks if there's a lowercase, then sets lower to true
			if (isupper(c)) upper = true; // Checks if there's a uppercase, then sets upper to true
		}
		else symbol = true; //If there's an input thats neither a number or a letter, it has to be a symbol, so symbol is set to true
	}

	return digit && symbol && upper && lower; //Returns the value of all four variables
}

