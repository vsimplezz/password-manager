#ifndef PASSWORDMANAGER_H
#define PASSWORDMANAGER_H

#include <iostream>
#include <vector>
using namespace std;

class PasswordManager {
private:
	string masterPassword; //Private variable for the master password
	vector<pair<string, string>> credentials; //Pairs two values in a vector (for username and password)
	string encrypt(const string input); //Private function to encrypt a passsword
	string decrypt(const string input); //Private function to decrypt a password
	string filename; //Private variable for the filename where passwords are stored
	int findUser(const string& username); //Private function to find a username in the vector


public:
	PasswordManager();

	void setMasterPassword(const string& password); //Sets the master password
	bool authenticate(const string& attempt); //Authenticates the master password
	bool addCredential(const string& username, const string& password); //Adds a username and password pair to the vector
	bool deleteCredential(const string& username); //Deletes a username and password pair from the vector
	string getPassword(const string& username); //Gets the password for a given username
	void saveToFile(); //Saves the current credentials to a file
	void fetchFromFile(); //Fetches the credentials from a file
	void listCredentials(); //Lists all stored usernames
	bool updatePassword(const string& username, const string& newPassword); //Updates the password for a given username
	string getMasterPassword() const; //Gets the master password
	bool strongPassword(const string& password); //Ensures password is strong


};


#endif