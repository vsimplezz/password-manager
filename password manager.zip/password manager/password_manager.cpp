#include <iostream>
#include "password_manager.h"
using namespace std;


int main()
{
	PasswordManager manager; //Declares manager as a Manager object
	manager.fetchFromFile(); //Fetches whatever is in the text file that stores passwords

	cout << "Welcome to the Password Manager!" << endl;

	if (manager.getMasterPassword().empty()) { //If the text file doesn't have a master password, the following code executes
		cout << "No master password set. Enter your desired master password: ";
		string newPass;
		cin >> newPass;
		manager.setMasterPassword(newPass); //Sets the master password as whatever was put into newPass
		manager.saveToFile(); //Saves the change
		cout << "Master password set!" << endl;
	}

	string attempt;
	int tries = 0; //Sets current amount of tries as 0
	const int maxTries = 3; //Sets maximum attempts to enter master password as 3

	while (tries < maxTries) { //As long as the value in tries is lower than maxTries, the following code runs
		cout << "Enter master password: ";
		cin >> attempt;

		if (manager.authenticate(attempt)) { //If the value in attempt matches the master password, grants access to the program
			cout << "Welcome!" << endl;
			break;
		}
		tries++; //Adds one to the tries counter
		cout << "Error, wrong password. Tries left: " << maxTries - tries << endl; //Prints the text and the remaining number of tries
	}
	if (tries == maxTries) { //If the value in tries matches the value of maxTries (3), the program quits
		cout << "Too many tries, goodbye." << endl;
		return 0;
	}

	int s;
	string user;
	string pass;
	string q;
	int z = 0;
	int maxZ = 3;



	while (true) {
		cout << "Menu" << endl;
		cout << "1) Add Credential" << endl;
		cout << "2) Get Credentials" << endl;
		cout << "3) Delete Credential" << endl;
		cout << "4) Save to file" << endl;
		cout << "5) Fetch from file" << endl;
		cout << "6) List all usernames currently saved" << endl;
		cout << "7) Exit" << endl;
		cin >> s;
		if (cin.fail()) { //If the input is invalid
			cin.clear(); //Clears the fail state
			cin.ignore(1000, '\n'); //Ignores the invalid input
			cout << "Error, invalid input. Please try again" << endl;
			z++; // Adds one to the invalid input counter
			if (z == maxZ) { //If the value in z matches the value in maxZ (3), the program quits
				cout << "Too many invalid inputs, quitting." << endl;
				return 0;
			}
			continue;


			switch (s) {
			case 1:
				cout << "Please enter the username and password you would like to save: ";
				cin >> user;
				cin >> pass;
				cout << endl;
				manager.addCredential(user, pass); //Passes the variables user and pass to the addCredential function
				cout << endl;
				break;

			case 2:
				cout << "What username would you like to get the password for? ";
				cin >> user;
				pass = manager.getPassword(user); //Passes the variable user to the getPassword function and stores the returned password in pass
				cout << "Username is " << user << " and password is " << pass << endl;
				cout << endl;
				break;

			case 3:
				cout << "Enter the username for the credentials you'd like to delete: ";
				cin >> user;
				manager.deleteCredential(user); //Passes the variable to the deleteCredential function
				cout << endl;
				break;

			case 4:
				manager.saveToFile(); //Calls the saveToFile function to save changes made
				cout << "Changes saved!" << endl;
				break;

			case 5:
				manager.fetchFromFile(); //Calls the fetchFromFile function to get previously saved data from the text file
				cout << "Data fetched from file." << endl;
				break;
			case 6:
				manager.listCredentials(); //Calls the listCredentials function to list all saved usernames	
				cout << endl;
				break;
			case 7:
				cout << "Are you sure you want to quit? Press Y to confirm or N to stay: ";
				cin >> q;
				if (q == "Y" || q == "y") { //If q is Y or y, the program quits
					cout << "Goodbye!" << endl;
					return 0;
				}
				else if (q == "N" || q == "n") { //If q is N or n, the program returns to the menu
					cout << "No problem, returning to menu." << endl;
					break;
				}
				else {
					cout << "Invalid input. Quitting anyway." << endl;
					return 0;
				}
			default:
				cout << "Invalid input, please try again" << endl;
				z++; //Adds one to the invalid input counter
				if (z == maxZ) { //If the value in z matches the value in maxZ (3), the program quits
					cout << "Too many invalid inputs, quitting." << endl;
					return 0;
				}
				break;
			}


		}
		return 0;




	}
}


